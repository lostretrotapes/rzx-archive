Dark Sceptre

The original darksceptre.rzx includes several minutes of the game loading in the recording.

Mark Woodmass has created a cropped version with this removed, thanks Mark! However, this version doesn't play back in SPIN, so the original is still included for SPIN users.