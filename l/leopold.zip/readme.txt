Spent a long time recording this huge game, but when I get to "CUT HAIR" it won't let me do it, saying that the pony rears up, not wanting its hair cut with a broadsword.

Looking back over the solution I suppose this means I should be using the KNIFE, which I don't have at this point -- perhaps the thief stole it. But I believe I followed the solution correctly. RZX attached, as far as I got. It's in "can continue recording" state though it seems the game is now unwinnable.

Solution may be worth rechecking.