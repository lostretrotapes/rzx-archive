This is a walkthrough of Edd the Duck game.
The game seems to have a bug at level 7.
You should be able to collect 20 stars, but there are only
19 stars in this level. Some graphics also seems to be damaged.
To be able to complete level 7, you should use POKE 27873,19 at
the beggining of this level.You can also use POKE 27873,1 this way
you  will have  to collect only one star:)
