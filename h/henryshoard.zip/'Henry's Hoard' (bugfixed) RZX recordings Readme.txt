"Henry's Hoard" (bugfixed) - a set of RZX recordings

"Henry's Hoard" is a game released by Martyn Brown and Andy Bigos (Alternative Software Ltd) in 1985. It uses a heavily-modified Jet Set Willy (JSW) game engine. The gameplay is almost identical to "JSW", while the title screen, Game Over screen and lives display have been extensively modified.

Three versions of "Henry's Hoard" exist: the 1985 edition, the 1986 edition and the latter edition with minor changes (and the year 1987 mentioned in the scrolling message on the title screen), which appeared on Side A of "MicroHobby" Issue 188: Tape 7 in May 1989.

All versions of the game suffer from critical bugs that make them impossible to complete. The RZX recordings in this ZIP file were made using bugfixed versions of the game, which can be downloaded from JSW Central (http://www.jswcentral.org/jsw48-04_hhoard.html) and from JetSet Willy & Manic Miner Community (http://jswmm.co.uk/files/file/66-henrys-hoard-bugfixed-versions/). The Readme in the ZIP explains all the problems in the original files and the fixes applied.

The recordings were made using the Rollback feature.

The 1985 edition and the 1986 edition were recorded in 48K mode. The MicroHobby version was recorded in 128K mode.

ZX Spin has an issue with some sounds in 48K mode. It does not play the in-game music of "Henry's Hoard". If you watch your RZX recordings in ZX Spin and are desperate to hear the in-game tune, watch the recording of the MicroHobby version.


Please let me know any comments you may have about the recordings at jetsetdanny@yahoo.com, and please visit my JSW Central website at www.jswcentral.org.


Enjoy!


Daniel Gromann, 10th April 2017