How to be a Hero

An infinite energy poke was used. The 3rd level seems to crash when you complete it.