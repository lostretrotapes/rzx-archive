The archive contains snapshot for the game and separate recordings for
each mission. All missions except mission-8 completed absolutelly
honestly, without rollbacks. I can't complete misson 8 without
cheating (time expires), so there are two recordings for that misson:
the one with well-known "invulnerability room" cheat and the other
with "infinite paper tape pieces" cheat discovered by me.

Kostya


UPDATE: 28-NOV-2005
-------------------
TOMCAT SUBMITTED A RECORDING OF LEVEL 8 COMPLETED WITHOUT CHEATING - SEE FILE SABOT2_8.RZX