The first 4 Missions plus a replay of killing starglider 1.
Done with Infy shields and missiles because Im sneaky like that.

Enjoy !