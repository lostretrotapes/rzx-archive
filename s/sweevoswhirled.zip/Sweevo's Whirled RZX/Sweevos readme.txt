Unfortunately, Sweevo's Whirled has a bug that prevents you from reaching fully active status. Due to the layout of the rooms there is one brownie that is unattainable. Therefore we have taken the game as far as we can, ending the first RZX in the room below this brownie. We then made a second RZX in which we used a poke (courtesy of Mr. Anonymous) to create an air vent so we can shoot up to the next level and get the final brownie. We then complete the game in the normal manner. Many thanks to Mr Anonymous for the pokes and also to Jim Langmead whose helpful hints and info about this game (and Sweevo's World) made things a heck of a lot easier.

Cheers,

xmikex and Jamie  