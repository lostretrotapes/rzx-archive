STANLEY AND THE WALLBANGERS

The game has a bug, making it impossible to complete, I believe.

At level 19, one of the items needed to collect is in such a place
that trying to take it means instant death.

Maybe there is some trick to take it, if you know it, you're better than me :)

I used following pokes to make the item accessible:

POKE 56717,47
POKE 56740,107
POKE 63640,1