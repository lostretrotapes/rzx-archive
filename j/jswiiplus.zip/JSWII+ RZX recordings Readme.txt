"JSWII+" - a set of RZX recordings


[26th March 2017 update]


"Jet Set Willy II+" is an updated version of the classic game "Jet Set Willy II: The Final Frontier" (Software Projects Ltd, 1985), created by Derrick P. Rowson, the author of the original game. The new version was released in 2016 and announced, inter alia, on Julian D. A. Wiseman's website (http://www.jdawiseman.com/papers/games/jsw2/jsw2_updated.html). The latest revision ("the last update") is Version +e.22, released on Facebook on 10th January 2017 and available for download from JetSet Willy & Manic Miner Community website (http://jswmm.co.uk/topic/284-file-jsw-ve22-rv1/).

This ZIP package contains RZX recordings of the game, made using the Rollback feature. They were created aiming at maximum efficiency in collecting the items. Hence the rooms which contain no items and do not have to be visited on the way to other rooms have been omitted.


There are two recordings of the current revision - Version +e.22 - of the game:

1. "JSWII+ Version 22 298 items.rzx"

The scrolling message on the title screen tells the player that "Willy thinks he needed to collect 298 objects." Indeed, collecting 298 items triggers the game ending, i.e. makes Maria disappear from the bedroom door and sets Willy on the "toilet run" after he has jumped onto the bed. There are 325 items possible to collect within the main playing area of the game (before triggering the final sequence). So not all items need to be collected in order to complete the game.

The recording "JSWII+ Version 22 298 items.rzx" shows the game being completed in less than one hour of in-game time - the end game room "Oh $#!+!The Central Cavern!" is reached at 00:52:59. 299 items are collected (the minimum number necessary to trigger the toilet run plus one; the additional item is the bathroom tap, collected inadvertently during the toilet run; five more items are collected in the end game room). A number of lives are lost along the way in order to gain time. 120 rooms (out of a total of 146) have been visited and three spare lives are left at the end of the game.


2. "JSWII+ Version 22 325 items.rzx"

This is the "standard" recording of the game, showing its completion with all of the items collected (325 plus 5 more in the first of the end game rooms) and a loss of one life (necessary to enter the "Glitch in Holodeck" mini-maze where 60 items can be collected). The room "Oh $#!+!The Central Cavern!" is reached at 01:15:50 in-game time. 140 rooms (out of a total of 147) have been visited (the omitted rooms are: "Swimming Pool", "Entrance To Hades", "Well", "Dinking Vater ?", "Without A Limb", "Eureka" and "cheat") and 16 spare lives are left at the end of the game.


As a historical curiosity, a set of recordings of an earlier revision of "JSWII+" - Version +e.2 - is also included within a separate ZIP file. It contains three recordings:


1. "JSWII+ Version 2 180 items.rzx"

This recording shows the game being completed in less than three quarters of an hour (in-game time) - the room "Oh $#!+!The Central Cavern!" is reached at 00:44:42. 180 items (in this revision, the minimum number necessary to trigger the toilet run) are collected (plus seven more items in the end game rooms) and a number of lives are lost along the way in order to gain time. 104 rooms (out of a total of 141 in this revision) have been visited and one spare life is left at the end of the game.


2. "JSWII+ Version 2 207 items.rzx"

This is the "standard" recording of this revision of the game, showing its completion with all of the items collected (207 plus seven more in the end game rooms) and no loss of life. The room "Oh $#!+!The Central Cavern!" is reached at 01:12:56 in-game time. 129 rooms (out of a total of 141) have been visited at the end of the game.


3. "JSWII+ Version 2 260 items.rzx"

Contrary to what happens in the original game, in "JSWII+" the end game room "Oh $#!+!The Central Cavern!" is playable. After the player has been teleported there from "The Bathroom" (notably, it is one teleport which does not have the typical teleport effect - it is instantaneous), they can collect five more items there. Once this has been done, the player can teleport to a depleted version of "The Off Licence", with only two items to collect. Collecting them brings the total up to 214.

From this point on, it seems that according to the author's intention the game is still playable, but the player is caught between two rooms: "The Off Licence", with a teleport below the yellow skull taking the player back to "Oh $#!+!The Central Cavern!" (irrespectively of whether or not the two items in "The Off Licence" have been collected), and "Oh $#!+!The Central Cavern!", with a teleport taking the player to "The Off Licence".

However, exploiting an unintended loophole which is present in this revision of the game, the player can jump over the teleport in "The Off Licence" (under the yellow skull) and exit the room to the left, returning to the main playing area, now devoid of items. The player can move through the rooms normally until reaching "First Landing", where the toilet run effect is now in place at all times. If the player enters "First Landing" from "To The Kitchen / Main Stairway", they will just get stuck. However, if they do a detour through the Kitchen rooms, "Banyan Tree" and "Nightmare Room", they will start the toilet run in "First Landing" properly, and it will take them back to "The Bathroom" and (through teleportation) to "Oh $#!+!The Central Cavern!". From there they can teleport to "The Off Licence", where the two items, previously collected, appear again, as if they had not been collected yet.

They can be collected, increasing the items score by two. The player can then repeat the whole loop again, jumping over the teleport in "The Off Licence" and going left, then re-starting the toilet run in "First Landing". The loop can probably be repeated infinitely, yielding two additional items every time (time consuming as it is). The recording "JSWII+ Version 2 260 items.rzx" shows just that, with the number of 256 items collected reached at 3:14:48 of in-game time. This is normally the maximum number of items one can collect in any JSW game. Interestingly, after continuing the loop, the number of items can be increased beyond this boundary - the recording goes on to show 258 items collected at 3:20:22 in-game time and then 260 items collected at 03:26:00 in-game time (the recording can be played till the end in ZX Spin; there may be an error message in Spectaculator).


Finally, a note about the "Glitch in Holodeck" mini-maze:

It is accessible from the lower east of "Shuttle Bay". It comprises four rooms: one without any guardians, two with a bird and one with a dumbbell. There are 15 items in each of these rooms in Version +e.22 of the game. The room numbering does not matter as far as gameplay is concerned. The easiest way to pass through the maze is to keep walking right (jumping over the gap in the floor, so as to always exit to the right rather than downwards).


Please let me know any comments you may have about the recordings at jetsetdanny@yahoo.com, and please visit my JSW Central website at www.jswcentral.org.


Enjoy!


Daniel Gromann, 26th March 2017