"Jet Set Mixup" - a set of RZX recordings

"Jet Set Mixup" is a redesign of the classic game "Jet Set Willy", created by the members of the Jet Set Willy and Manic Miner Community (jswmm.co.uk). Its layout is almost identical to that of "Jet Set Willy", but most of the original guardians have gone on holiday, and have been replaced on duty by sprites from "Manic Miner" and "Jet Set Willy II". Furthermore, the player is offered a choice of sprites with which they can explore Willy's mansion, which reinforces the "mixed up" atmosphere of the game.

The game can be downloaded at http://jswmm.co.uk/topic/357-file-jet-set-mixup/.

This ZIP package contains RZX recordings of the game, made using the Rollback feature, showing the completion of the game, without loss of life, with every possible sprite choice.

Please let me know any comments you may have about the recordings at jetsetdanny@yahoo.com, and please visit my JSW Central website at www.jswcentral.org.


Enjoy!


Daniel Gromann, 23rd July 2017