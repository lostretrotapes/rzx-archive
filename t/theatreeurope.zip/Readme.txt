Theatre Europe

Watch the forces of Nato hold and almost destroy the Warsaw Pact army in "TEurope NATO Win"

And then..

See the Soviets steamroller over western Europe pushing the NATO alliance back to the Atlantic shores in "TEurope Wpact Win"

Enjoy :)