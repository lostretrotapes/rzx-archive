Tommy 

This game has 4 possible solutions (it depends on the photo that
appears at the left of the energy bar)