I used a poke. It reduces number of items to collect required to complete a level. Without it the game would take 10 hours or more to complete which was too much for me.

Rafal