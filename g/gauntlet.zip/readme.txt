Here is 100-odd levels of Gauntlet. Don't think there is an ending so I've just done one whole "loop" of the tape and recorded an RZX for each loading block. Levels tend to be assigned randomly after about level 5 so there are some repeats, but it's a good selection overall. 

Jamie.